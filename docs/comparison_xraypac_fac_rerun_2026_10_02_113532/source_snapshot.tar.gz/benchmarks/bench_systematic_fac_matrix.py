"""Systematic atomx-vs-FAC comparison matrix (2026-10-02 program).

One place that answers "how close is atomx to FAC" across the three
observable families requested for the validation program:

1. Subshell photoionization cross sections  sigma_i(omega)
2. Electron decay rates: Auger  Gamma_A,i  and radiative/fluorescence  A_r,i
3. X-ray scattering cross sections  d sigma/d Omega (elastic + inelastic)

Existing panels (benchmarks/, all with live gates in tests/):
  PI/RR  results_fac_pi_rr.csv        (test_pi_rr_vs_fac.py)
  CE     results_fac_ce.csv
  CI     results_fac_ci.csv
  AI     results_fac_ai.csv  +  tests/data/fe17_kll_auger_fac.json
         + tests/data/fe17_kll_aitable.json (per-level AITable)
  Auger vs XATOM (non-relativistic anchor):
         tests/test_auger_ne_kll_xatom.py (LS chain, Ne KLL 1.025x total)

This harness enumerates the matrix cells, reports which have live
coverage and which are missing, and is the runner skeleton for filling
the gaps.  The relativistic angular track (angular_mode="jj",
AutoionizeRateUTA0 transcription) lands per the atomx trace spec.

Run:  uv run --extra dev python benchmarks/bench_systematic_fac_matrix.py
"""

from __future__ import annotations

import csv
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# (family, observable, case, panel/gate, status)
MATRIX = [
    ("PI", "subshell sigma_1s(omega)", "Fe25+ (H-like)",
     "benchmarks/results_fac_pi_rr.csv", "partial: K-shell 4%"),
    ("PI", "subshell sigma_2s/2p(omega)", "Fe24+ (Li-like capture)",
     "benchmarks/results_fac_pi_rr.csv", "partial: 12-23%"),
    ("PI", "subshell sigma_i(omega), Z panel", "Z = 6..54 K/L shells",
     None, "TODO: extend bench_fac_pi_rr over a Z grid"),
    ("DECAY", "Auger Gamma per subshell pair", "Ne KLL vs XATOM",
     "tests/test_auger_ne_kll_xatom.py", "live: 1.025x total (LS chain)"),
    ("DECAY", "Auger Gamma per resonance", "Fe XVII KLL vs FAC AITable",
     "tests/test_auger_fac_panel.py",
     "live: 4/5 in band; ILEV 32 at 0.34 (floor 0.40); jj UTA-0 next"),
    ("DECAY", "radiative A_r per subshell", "Fe cases",
     "tests/test_fac_dr_radiative.py",
     "partial: DR radiative; per-subshell fluorescence panel TODO"),
    ("DECAY", "Auger + radiative branch ratio (fluorescence yield)",
     "Z panel K-shell", None,
     "TODO: omega_K = A_r/(A_r+Gamma_A) vs FAC, the classic Z sweep"),
    ("SCATTER", "elastic X-ray f1/f2 form factor", "neutral Ne/Ar/Fe",
     None, "TODO: Rayleigh d_sigma/d_Omega vs FAC; no panel exists"),
    ("SCATTER", "inelastic (Compton) X-ray", "neutral Ne/Ar/Fe",
     None, "TODO: scipy/Compton profile vs FAC"),
]


def _row_ok(panel: str | None) -> str:
    if panel is None:
        return "-"
    p = ROOT / panel
    if not p.exists():
        return "MISSING FILE"
    if p.suffix == ".csv":
        with p.open(newline="", encoding="utf-8") as fh:
            n = len(list(csv.reader(fh)))
        return f"{n} rows"
    return "present"


def main() -> int:
    print(f"{'family':8s} {'observable':34s} {'case':30s} "
          f"{'panel':10s} status")
    print("-" * 110)
    for fam, obs, case, panel, status in MATRIX:
        print(f"{fam:8s} {obs:34s} {case:30s} "
              f"{_row_ok(panel):10s} {status}")
    print("-" * 110)
    missing = [m for m in MATRIX if m[4].startswith("TODO")]
    print(f"{len(missing)} TODO cells of {len(MATRIX)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
